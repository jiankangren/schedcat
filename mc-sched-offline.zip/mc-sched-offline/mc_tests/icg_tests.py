import unittest
from icg_dbf import IcgDBF


class TestIcgDBF(unittest.TestCase):

    def test_icg_assignment(self):
        pass

    def test_priority_assignment(self):
        pass

    def test_utilization_function(self):
        pass
