import unittest
from amc_rtb import AmcRtb
from amc_max import AmcMax


class AmcTest(unittest.TestCase):

    def test_amc_rtb_schedulability(self):
        pass

    def test_amc_max_schedulability(self):
        pass

    def test_amc_rtb_priority_assignment(self):
        pass

    def test_amc_max_priority_assignment(self):
        pass