import unittest
from amc_pt import PtAMC


class AmcPtTest(unittest.TestCase):

    def test_priority_assignment(self):
        pass

    def test_threshold_assignment(self):
        pass

    def test_schedulability(self):
        pass
