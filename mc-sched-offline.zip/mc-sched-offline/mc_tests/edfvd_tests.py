import unittest
from edfvd import EdfVD


class TestEDFVD(unittest.TestCase):

    def test_utilization_bound(self):
        pass

    def test_transformation_constant(self):
        pass

    def test_new_period_assignment(self):
        pass