import unittest
from zss import Zss


class TestZss(unittest.TestCase):

    def test_zero_slack_assignment(self):
        pass

    def test_priority_assignment(self):
        pass
