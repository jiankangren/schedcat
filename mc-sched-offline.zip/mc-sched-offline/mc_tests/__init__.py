"""
Common initializations.
"""
