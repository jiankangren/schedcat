import unittest
from audsley import Audsley


class TestAudsley(unittest.TestCase):

    def test_audsley_priority_assignment(self):
        pass

    def test_audsley_priority_pass(self):
        pass

    def test_audsley_priority_fail(self):
        pass
