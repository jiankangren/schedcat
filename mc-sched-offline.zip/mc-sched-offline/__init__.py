"""Component additions for MC schedulablity check.
   Includes the common headers.
"""
